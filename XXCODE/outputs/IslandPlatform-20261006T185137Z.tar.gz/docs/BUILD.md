# Build

Requirements: macOS 14+, Xcode 27/Swift 6, and no external dependency for the current prototype.

Run `./scripts/build` for the library and demo, `./scripts/test` for XCTest, and `swift run platform-demo` to exercise the local demo. An iOS application target is intentionally deferred until the public-facing adapter surface is expanded; the package already declares iOS 17 as a supported platform for future app targets.
