# Changelog

## 0.1.0 — 2026-10-06

- Created Swift package and local demo.
- Added capability-gated Island, assistant, wallpaper, jailbreak, package, and diagnostics foundations.
- Added feasibility, architecture, build, testing, security, and troubleshooting documentation.
- Added unit tests and build/test/diagnostic/package scripts.
